package com.systex.practice.model.entity.type;

public enum HolidayType {
    open, close
}

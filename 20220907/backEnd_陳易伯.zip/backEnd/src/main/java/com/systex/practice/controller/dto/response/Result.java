package com.systex.practice.controller.dto.response;

public class Result {
}
